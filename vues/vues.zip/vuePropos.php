﻿<!--commencer directement avec la div contenu-->
	<section class="pageAPropos">
        <h1 class="titrePagePropos"><?php echo $data["sommesT"]; ?></h1>
        <p class="descriptionPagePropos"><?php echo $data["sommesD"]; ?></p>
        <h1 class="titrePagePropos"><?php echo $data["missionT"]; ?></h1>
        <p class="descriptionPagePropos"><?php echo $data["missionD"]; ?></p>
        <h1 class="titrePagePropos"><?php echo $data["joindreT"]; ?></h1>
        <p class="descriptionPagePropos"><?php echo $data["joindreD"]; ?></p>
        <h1 class="titrePagePropos"><?php echo $data["partenaireT"]; ?></h1>
        <p class="descriptionPagePropos"><?php echo $data["partenaireD"]; ?></p>
    </section>
</div>	